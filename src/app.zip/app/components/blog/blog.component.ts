import { Component, OnInit } from '@angular/core';
import { DataService, BlogPost } from '../../services/data.service';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {
  blogPosts: BlogPost[] = [];

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.blogPosts = this.dataService.getBlogPosts();
  }
}
