import { Component, OnInit } from '@angular/core';
import { DataService, Service } from '../../services/data.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {
  services: Service[] = [];
  expandedService: number | null = null;
  selectedService: any = null;

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.services = this.dataService.getServices();
  }

  toggleService(serviceId: number) {
    this.expandedService = this.expandedService === serviceId ? null : serviceId;
  }


  openModal(service: any){
    this.selectedService = service;
  }

  closeModal(){
    this.selectedService = null;
  }

}

