import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService, Testimonial } from '../../services/data.service';
import { FeedbackService, Feedback } from '../../services/feedback.service';

interface CombinedTestimonial extends Testimonial {
  isFeedback?: boolean;
}

interface CombinedFeedback extends Feedback {
  avatar?: string;
  isFeedback?: boolean;
}

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.css']
})
export class TestimonialsComponent implements OnInit, OnDestroy {
  allTestimonials: (Testimonial | Feedback)[] = [];
  currentSlide = 0;
  autoSlideInterval: any;

  constructor(
    private dataService: DataService,
    private feedbackService: FeedbackService
  ) { }

  ngOnInit() {
    // Combine testimonials and recent feedbacks
    const testimonials = this.dataService.getTestimonials();
    const feedbacks = this.feedbackService.getAllFeedbacks();

    this.allTestimonials = [...testimonials, ...feedbacks];

    // If no testimonials, use feedbacks only
    if (this.allTestimonials.length === 0) {
      this.allTestimonials = testimonials;
    }
    this.autoSlideInterval = setInterval(() => {
      this.startAutoSlide();
    }, 2000); // Change slide every 2 seconds

  }

  ngOnDestroy() {
    if (this.autoSlideInterval) {
      clearInterval(this.autoSlideInterval);
    }
  }

  startAutoSlide() {
    this.nextSlide();
  }

  nextSlide() {
    this.currentSlide = (this.currentSlide + 1) % this.allTestimonials.length;
  }

  prevSlide() {
    this.currentSlide = (this.currentSlide - 1 + this.allTestimonials.length) % this.allTestimonials.length;
  }

  goToSlide(index: number) {
    this.currentSlide = index;
  }

  getStarArray(rating: number): number[] {
    return Array(rating).fill(0).map((x, i) => i);
  }

  isFeedback(item: any): item is Feedback {
    return 'message' in item && 'customerName' in item;
  }

  onMouseEnter() {
    if (this.autoSlideInterval) {
      clearInterval(this.autoSlideInterval);
    }
  }

  onMouseLeave() {
    this.startAutoSlide();
  }
}
